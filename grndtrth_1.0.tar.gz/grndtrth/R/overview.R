overview <-
function(x) {
        Number <- table(x)
        Percent <- round(prop.table(Number)*100)
        over <- rbind(Number,Percent)
        write.csv(over,"Overview_output.csv")
        over}
