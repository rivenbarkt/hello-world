accuracy <-
function(x) {
        Accurate <- ifelse(x$FLUCCS == x$Samp_LU,1,0)
        acc <- cbind(data.frame(x),Accurate)
        write.csv(acc,"Overview_output.csv")
        acc}
