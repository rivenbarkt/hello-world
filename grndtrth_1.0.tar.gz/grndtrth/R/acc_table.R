acc_table <-
function(x,sort_column) {
        a <- ddply(x,sort_column,transform,Accuracy_Percent=mean(Accurate))
        unique(a)
        write.csv(a)
        a}
